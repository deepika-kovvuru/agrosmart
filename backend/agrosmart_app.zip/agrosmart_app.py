from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import pymysql
pymysql.install_as_MySQLdb()

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://@10.206.61.210/agrosmart'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'agrosmart_secret'

db = SQLAlchemy(app)


# ─────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────

class User(db.Model):
    __tablename__ = 'users'
    id         = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name       = db.Column(db.String(255), nullable=False)
    email      = db.Column(db.String(255), unique=True, nullable=False)
    phone      = db.Column(db.String(50), nullable=False)
    password   = db.Column(db.String(255), nullable=False)
    state      = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ActiveSession(db.Model):
    __tablename__ = 'active_sessions'
    id       = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email    = db.Column(db.String(255), nullable=False)
    login_at = db.Column(db.DateTime, default=datetime.utcnow)

class FarmDetail(db.Model):
    __tablename__ = 'farm_details'
    id            = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id       = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    land_area     = db.Column(db.Numeric(10, 2), nullable=True)
    primary_crops = db.Column(db.String(255), nullable=True)
    soil_type     = db.Column(db.String(100), nullable=True)
    irrigation    = db.Column(db.String(100), nullable=True)
    region        = db.Column(db.String(255), nullable=True)
    updated_at    = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class MarketPrice(db.Model):
    __tablename__ = 'market_prices'
    id         = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mandi      = db.Column(db.String(100), nullable=False)
    commodity  = db.Column(db.String(100), nullable=False)
    category   = db.Column(db.String(50),  nullable=False)
    price      = db.Column(db.Numeric(10, 2), nullable=False)
    prev_price = db.Column(db.Numeric(10, 2), nullable=False)
    unit       = db.Column(db.String(20), default='qtl')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CropAdvisory(db.Model):
    __tablename__ = 'crop_advisories'
    id          = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    crop        = db.Column(db.String(100), nullable=False)
    emoji       = db.Column(db.String(10),  nullable=True)
    title       = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    priority    = db.Column(db.String(20), default='Info')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

class PestAlert(db.Model):
    __tablename__ = 'pest_alerts'
    id          = db.Column(db.Integer, primary_key=True, autoincrement=True)
    region      = db.Column(db.String(100), nullable=False)
    crop        = db.Column(db.String(100), nullable=False)
    pest_name   = db.Column(db.String(255), nullable=False)
    severity    = db.Column(db.String(20),  default='Medium')
    description = db.Column(db.Text, nullable=True)
    treatment   = db.Column(db.Text, nullable=True)
    reported_at = db.Column(db.DateTime, default=datetime.utcnow)

class Treatment(db.Model):
    __tablename__ = 'treatments'
    id          = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name        = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    type        = db.Column(db.String(50), nullable=False)   # Chemical / Fungicide / Bio-Pesticide
    crop        = db.Column(db.String(100), nullable=True)   # null = applicable to all
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

class FarmSchedule(db.Model):
    __tablename__ = 'farm_schedule'
    id           = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id      = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    activity     = db.Column(db.String(255), nullable=False)
    scheduled_at = db.Column(db.DateTime, nullable=False)
    status       = db.Column(db.String(20), default='pending')
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)

class FarmingTip(db.Model):
    __tablename__ = 'farming_tips'
    id          = db.Column(db.Integer, primary_key=True, autoincrement=True)
    icon        = db.Column(db.String(10),  nullable=False)
    title       = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    tag         = db.Column(db.String(50),  nullable=True)
    category    = db.Column(db.String(50),  nullable=True)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

class NewsArticle(db.Model):
    __tablename__ = 'news_articles'
    id             = db.Column(db.Integer, primary_key=True, autoincrement=True)
    category       = db.Column(db.String(50),  nullable=False)
    title          = db.Column(db.String(500), nullable=False)
    summary        = db.Column(db.Text, nullable=False)
    source         = db.Column(db.String(255), nullable=True)
    image_emoji    = db.Column(db.String(10),  nullable=True)
    category_color = db.Column(db.String(20),  nullable=True)
    is_featured    = db.Column(db.Boolean, default=False)
    published_at   = db.Column(db.DateTime, default=datetime.utcnow)


# ─────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────

@app.route('/signup', methods=['POST'])
def signup():
    try:
        data = request.get_json()
        required = ['name', 'email', 'phone', 'password', 'confirm_password']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        if data['password'] != data['confirm_password']:
            return jsonify({'error': 'Passwords do not match'}), 400
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already registered'}), 409
        new_user = User(
            name=data['name'], email=data['email'], phone=data['phone'],
            password=generate_password_hash(data['password']),
            state=data.get('state', None)
        )
        db.session.add(new_user)
        db.session.commit()
        return jsonify({'message': 'User registered successfully'}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        if not data or 'email' not in data or 'password' not in data:
            return jsonify({'error': 'Email and password required'}), 400
        user = User.query.filter_by(email=data['email']).first()
        if not user or not check_password_hash(user.password, data['password']):
            return jsonify({'error': 'Invalid credentials'}), 401
        session = ActiveSession(email=user.email)
        db.session.add(session)
        db.session.commit()
        return jsonify({'message': 'Login successful', 'user': {
            'id': user.id, 'name': user.name, 'email': user.email,
            'phone': user.phone, 'state': user.state
        }}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/get_current_user', methods=['GET'])
def get_current_user():
    try:
        last = ActiveSession.query.order_by(ActiveSession.id.desc()).first()
        if not last:
            return jsonify({'error': 'No active user found'}), 404
        user = User.query.filter_by(email=last.email).first()
        if not user:
            return jsonify({'error': 'User not found'}), 404
        return jsonify({'id': user.id, 'name': user.name, 'email': user.email,
                        'phone': user.phone, 'state': user.state}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/logout', methods=['POST'])
def logout():
    try:
        data = request.get_json()
        email = data.get('email') if data else None
        if not email:
            return jsonify({'error': 'Email required'}), 400
        ActiveSession.query.filter_by(email=email).delete()
        db.session.commit()
        return jsonify({'message': 'Logged out successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# PROFILE & FARM DETAILS
# ─────────────────────────────────────────

@app.route('/profile/<int:user_id>', methods=['PUT'])
def update_profile(user_id):
    try:
        data = request.get_json()
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        user.name  = data.get('name',  user.name)
        user.phone = data.get('phone', user.phone)
        user.state = data.get('state', user.state)
        db.session.commit()
        return jsonify({'message': 'Profile updated'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/farm_details/<int:user_id>', methods=['GET'])
def get_farm_details(user_id):
    try:
        farm = FarmDetail.query.filter_by(user_id=user_id).first()
        if not farm:
            return jsonify({'error': 'Farm details not found'}), 404
        return jsonify({
            'id': farm.id, 'user_id': farm.user_id,
            'land_area': float(farm.land_area) if farm.land_area else None,
            'primary_crops': farm.primary_crops, 'soil_type': farm.soil_type,
            'irrigation': farm.irrigation, 'region': farm.region
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/farm_details/<int:user_id>', methods=['PUT'])
def update_farm_details(user_id):
    try:
        data = request.get_json()
        farm = FarmDetail.query.filter_by(user_id=user_id).first()
        if not farm:
            farm = FarmDetail(user_id=user_id)
            db.session.add(farm)
        farm.land_area     = data.get('land_area',     farm.land_area)
        farm.primary_crops = data.get('primary_crops', farm.primary_crops)
        farm.soil_type     = data.get('soil_type',     farm.soil_type)
        farm.irrigation    = data.get('irrigation',    farm.irrigation)
        farm.region        = data.get('region',        farm.region)
        db.session.commit()
        return jsonify({'message': 'Farm details updated'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# CROP ADVISORY
# ─────────────────────────────────────────

@app.route('/crop_advisories/<int:user_id>', methods=['GET'])
def get_crop_advisories(user_id):
    try:
        crop = request.args.get('crop')
        query = CropAdvisory.query.filter_by(user_id=user_id)
        if crop:
            query = query.filter_by(crop=crop)
        advisories = query.order_by(CropAdvisory.created_at.desc()).all()
        return jsonify([{
            'id': a.id, 'crop': a.crop, 'emoji': a.emoji,
            'title': a.title, 'description': a.description,
            'priority': a.priority,
            'created_at': a.created_at.strftime('%d %b %Y, %I:%M %p')
        } for a in advisories]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/crop_advisories', methods=['POST'])
def add_crop_advisory():
    try:
        data = request.get_json()
        required = ['user_id', 'crop', 'title', 'description']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        advisory = CropAdvisory(
            user_id=data['user_id'], crop=data['crop'],
            emoji=data.get('emoji', '🌿'), title=data['title'],
            description=data['description'], priority=data.get('priority', 'Info')
        )
        db.session.add(advisory)
        db.session.commit()
        return jsonify({'message': 'Advisory saved', 'id': advisory.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/crop_advisories/<int:advisory_id>', methods=['DELETE'])
def delete_crop_advisory(advisory_id):
    try:
        advisory = CropAdvisory.query.get(advisory_id)
        if not advisory:
            return jsonify({'error': 'Advisory not found'}), 404
        db.session.delete(advisory)
        db.session.commit()
        return jsonify({'message': 'Advisory deleted'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# PEST & DISEASE
# ─────────────────────────────────────────

@app.route('/pest_alerts', methods=['GET'])
def get_pest_alerts():
    try:
        region = request.args.get('region')
        crop   = request.args.get('crop')
        query  = PestAlert.query
        if region:
            query = query.filter_by(region=region)
        if crop:
            query = query.filter_by(crop=crop)
        alerts = query.order_by(PestAlert.reported_at.desc()).all()
        return jsonify([{
            'id': a.id, 'region': a.region, 'crop': a.crop,
            'pest_name': a.pest_name, 'severity': a.severity,
            'description': a.description, 'treatment': a.treatment,
            'reported_at': a.reported_at.strftime('%d %b %Y')
        } for a in alerts]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/pest_alerts', methods=['POST'])
def add_pest_alert():
    try:
        data = request.get_json()
        required = ['region', 'crop', 'pest_name']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        alert = PestAlert(
            region=data['region'], crop=data['crop'],
            pest_name=data['pest_name'], severity=data.get('severity', 'Medium'),
            description=data.get('description', ''), treatment=data.get('treatment', '')
        )
        db.session.add(alert)
        db.session.commit()
        return jsonify({'message': 'Alert added', 'id': alert.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/treatments', methods=['GET'])
def get_treatments():
    try:
        crop  = request.args.get('crop')
        ttype = request.args.get('type')
        query = Treatment.query
        if crop:
            query = query.filter((Treatment.crop == crop) | (Treatment.crop == None))
        if ttype:
            query = query.filter_by(type=ttype)
        items = query.order_by(Treatment.created_at.desc()).all()
        return jsonify([{
            'id': t.id, 'name': t.name, 'description': t.description,
            'type': t.type, 'crop': t.crop
        } for t in items]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/treatments', methods=['POST'])
def add_treatment():
    try:
        data = request.get_json()
        required = ['name', 'description', 'type']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        t = Treatment(
            name=data['name'], description=data['description'],
            type=data['type'], crop=data.get('crop', None)
        )
        db.session.add(t)
        db.session.commit()
        return jsonify({'message': 'Treatment added', 'id': t.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# MARKET PRICES
# ─────────────────────────────────────────

@app.route('/market_prices', methods=['GET'])
def get_market_prices():
    try:
        mandi    = request.args.get('mandi')
        category = request.args.get('category')
        query    = MarketPrice.query
        if mandi:
            query = query.filter_by(mandi=mandi)
        if category and category != 'All':
            query = query.filter_by(category=category)
        prices = query.all()
        result = []
        for p in prices:
            change = float(p.price) - float(p.prev_price)
            result.append({
                'id': p.id, 'mandi': p.mandi, 'commodity': p.commodity,
                'category': p.category, 'price': float(p.price),
                'prev_price': float(p.prev_price), 'change': round(change, 2),
                'is_up': change >= 0, 'unit': p.unit,
                'updated_at': p.updated_at.strftime('%d %b %Y %I:%M %p') if p.updated_at else None
            })
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/market_prices', methods=['POST'])
def add_market_price():
    """Add a new commodity price entry"""
    try:
        data = request.get_json()
        required = ['mandi', 'commodity', 'category', 'price', 'prev_price']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        price = MarketPrice(
            mandi=data['mandi'], commodity=data['commodity'],
            category=data['category'], price=data['price'],
            prev_price=data['prev_price'], unit=data.get('unit', 'qtl')
        )
        db.session.add(price)
        db.session.commit()
        return jsonify({'message': 'Price added', 'id': price.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/market_prices/<int:price_id>', methods=['PUT'])
def update_market_price(price_id):
    """Update existing commodity price (admin use)"""
    try:
        data  = request.get_json()
        price = MarketPrice.query.get(price_id)
        if not price:
            return jsonify({'error': 'Price not found'}), 404
        price.prev_price = float(price.price)  # shift current to prev
        price.price      = data.get('price', price.price)
        price.updated_at = datetime.utcnow()
        db.session.commit()
        return jsonify({'message': 'Price updated'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/mandis', methods=['GET'])
def get_mandis():
    try:
        mandis = db.session.query(MarketPrice.mandi).distinct().all()
        return jsonify([m[0] for m in mandis]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# FARM SCHEDULE
# ─────────────────────────────────────────

@app.route('/farm_schedule/<int:user_id>', methods=['GET'])
def get_farm_schedule(user_id):
    try:
        schedules = FarmSchedule.query.filter_by(user_id=user_id)\
            .order_by(FarmSchedule.scheduled_at.asc()).all()
        return jsonify([{
            'id': s.id, 'activity': s.activity,
            'scheduled_at': s.scheduled_at.strftime('%d %b %Y, %I:%M %p'),
            'status': s.status
        } for s in schedules]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/farm_schedule', methods=['POST'])
def add_farm_schedule():
    try:
        data = request.get_json()
        required = ['user_id', 'activity', 'scheduled_at']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        schedule = FarmSchedule(
            user_id=data['user_id'], activity=data['activity'],
            scheduled_at=datetime.strptime(data['scheduled_at'], '%Y-%m-%d %H:%M'),
            status='pending'
        )
        db.session.add(schedule)
        db.session.commit()
        return jsonify({'message': 'Activity added', 'id': schedule.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/farm_schedule/<int:schedule_id>', methods=['PUT'])
def update_schedule_status(schedule_id):
    try:
        data     = request.get_json()
        schedule = FarmSchedule.query.get(schedule_id)
        if not schedule:
            return jsonify({'error': 'Schedule not found'}), 404
        schedule.status = data.get('status', schedule.status)
        db.session.commit()
        return jsonify({'message': 'Status updated'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/farm_schedule/<int:schedule_id>', methods=['DELETE'])
def delete_farm_schedule(schedule_id):
    try:
        schedule = FarmSchedule.query.get(schedule_id)
        if not schedule:
            return jsonify({'error': 'Schedule not found'}), 404
        db.session.delete(schedule)
        db.session.commit()
        return jsonify({'message': 'Activity deleted'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# FARMING TIPS & NEWS
# ─────────────────────────────────────────

@app.route('/farming_tips', methods=['GET'])
def get_farming_tips():
    try:
        category = request.args.get('category')
        query    = FarmingTip.query
        if category:
            query = query.filter_by(category=category)
        tips = query.order_by(FarmingTip.created_at.desc()).all()
        return jsonify([{
            'id': t.id, 'icon': t.icon, 'title': t.title,
            'description': t.description, 'tag': t.tag, 'category': t.category
        } for t in tips]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/farming_tips', methods=['POST'])
def add_farming_tip():
    try:
        data = request.get_json()
        required = ['icon', 'title', 'description']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        tip = FarmingTip(
            icon=data['icon'], title=data['title'],
            description=data['description'], tag=data.get('tag', ''),
            category=data.get('category', 'General')
        )
        db.session.add(tip)
        db.session.commit()
        return jsonify({'message': 'Tip added', 'id': tip.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/news_articles', methods=['GET'])
def get_news_articles():
    try:
        category = request.args.get('category')
        featured = request.args.get('featured')
        limit    = int(request.args.get('limit', 20))
        query    = NewsArticle.query
        if category and category != 'All':
            query = query.filter_by(category=category)
        if featured == 'true':
            query = query.filter_by(is_featured=True)
        articles = query.order_by(NewsArticle.published_at.desc()).limit(limit).all()
        return jsonify([{
            'id': a.id, 'category': a.category, 'title': a.title,
            'summary': a.summary, 'source': a.source,
            'image_emoji': a.image_emoji, 'category_color': a.category_color,
            'is_featured': a.is_featured,
            'published_at': a.published_at.strftime('%d %b %Y')
        } for a in articles]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/news_articles', methods=['POST'])
def add_news_article():
    try:
        data = request.get_json()
        required = ['category', 'title', 'summary']
        if not data or not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        article = NewsArticle(
            category=data['category'], title=data['title'],
            summary=data['summary'], source=data.get('source', 'Agrosmart'),
            image_emoji=data.get('image_emoji', '📰'),
            category_color=data.get('category_color', '#2D6A4F'),
            is_featured=data.get('is_featured', False)
        )
        db.session.add(article)
        db.session.commit()
        return jsonify({'message': 'Article added', 'id': article.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

def _seed_static_data():
    """Seed treatments, tips, news if tables are empty"""

    # Treatments
    if Treatment.query.count() == 0:
        treatments = [
            Treatment(name='Chlorpyrifos 20 EC', type='Chemical',
                description='Spray 2ml/L water for FAW control. Apply during evening hours.'),
            Treatment(name='Tricyclazole 75 WP', type='Fungicide',
                description='Use 0.6g/L water for blast control. 2 sprays 15 days apart.'),
            Treatment(name='Neem Oil Spray', type='Bio-Pesticide',
                description='Eco-friendly: 5ml/L water, spray weekly for BPH and aphids.'),
            Treatment(name='Imidacloprid 17.8 SL', type='Chemical',
                description='Apply 0.3ml/L water for sucking pests like whitefly and BPH.'),
            Treatment(name='Copper Oxychloride', type='Fungicide',
                description='3g/L water for bacterial and fungal diseases. Spray at first sign.'),
            Treatment(name='Trichoderma viride', type='Bio-Pesticide',
                description='Soil application 2.5kg/acre for root rot and damping off prevention.'),
        ]
        for t in treatments:
            db.session.add(t)

    # Farming tips
    if FarmingTip.query.count() == 0:
        tips = [
            FarmingTip(icon='🌱', title='Seed Treatment', tag='Pre-Sowing', category='Sowing',
                description='Treat seeds with fungicide + insecticide before sowing to prevent soil-borne diseases.'),
            FarmingTip(icon='🌿', title='Intercropping Benefits', tag='Soil Health', category='Soil',
                description='Growing legumes alongside cereals improves soil nitrogen naturally, reducing fertilizer cost by 25%.'),
            FarmingTip(icon='💊', title='Nutrient Management', tag='Fertilization', category='Fertilizer',
                description='Split fertilizer application (basal + top-dress) improves uptake efficiency.'),
            FarmingTip(icon='🔍', title='Scouting Protocol', tag='Pest Control', category='Pest',
                description='Walk fields in W-pattern twice a week. Early detection saves 70% on pesticide costs.'),
            FarmingTip(icon='💧', title='Deficit Irrigation', tag='Water Saving', category='Irrigation',
                description='Apply irrigation at critical growth stages only. Saves 30% water vs continuous flooding.'),
            FarmingTip(icon='🌾', title='Crop Rotation', tag='Soil Health', category='Soil',
                description='Rotate crops every season to break pest cycles and improve soil structure naturally.'),
        ]
        for t in tips:
            db.session.add(t)

    # News articles
    if NewsArticle.query.count() == 0:
        articles = [
            NewsArticle(category='Market Update', is_featured=True, image_emoji='🌾',
                category_color='#E07B39', source='Agrosmart Market Daily',
                title='Wheat Prices Surge 12% Amid Global Supply Concerns',
                summary='International wheat futures climbed sharply this week as drought conditions persist in key growing regions.'),
            NewsArticle(category='Technology', image_emoji='💧',
                category_color='#2196F3', source='FarmTech Review',
                title='AI-Powered Irrigation Systems Cut Water Usage by 40%',
                summary='Smart drip systems with soil-moisture sensors help farmers reduce water consumption while maintaining yield.'),
            NewsArticle(category='Pest Alert', image_emoji='🐛',
                category_color='#E53935', source='Crop Protection News',
                title='Fall Armyworm Detected in Northern Districts',
                summary='Agricultural authorities issued an advisory after fall armyworm infestations were confirmed in multiple zones.'),
            NewsArticle(category='Policy', image_emoji='🏛️',
                category_color='#7B1FA2', source='Agrosmart Policy Hub',
                title='Govt Announces ₹50,000 Cr Subsidy Package for Farmers',
                summary='New relief package supports small farmers with fertilizer subsidies and low-interest crop loans.'),
            NewsArticle(category='Climate', image_emoji='🌧️',
                category_color='#00897B', source='Weather & Agro',
                title='IMD Forecasts Above-Normal Monsoon This Season',
                summary='India Meteorological Department predicts 106% of long-period average rainfall this Kharif season.'),
        ]
        for a in articles:
            db.session.add(a)

    # Pest alerts
    if PestAlert.query.count() == 0:
        alerts = [
            PestAlert(region='Kurnool', crop='Paddy', pest_name='Brown Planthopper',
                severity='High', description='Yellowing and drying of plants in patches.',
                treatment='Apply Imidacloprid 17.8% SL at 0.3ml/L water.'),
            PestAlert(region='Kurnool', crop='Maize', pest_name='Fall Armyworm',
                severity='High', description='Leaf damage with circular holes.',
                treatment='Spray Chlorpyrifos 20% EC at 2ml/L water.'),
            PestAlert(region='Kurnool', crop='Cotton', pest_name='Whitefly',
                severity='Medium', description='Yellowing of leaves, sticky honeydew.',
                treatment='Apply Acetamiprid 20% SP at 0.2g/L water.'),
        ]
        for a in alerts:
            db.session.add(a)

    db.session.commit()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        _seed_static_data()
    app.run(debug=True, host='0.0.0.0', port=5000)